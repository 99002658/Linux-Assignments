#ifndef __HMYSTRING_H
#define __HMYSTRING_H


unsigned int my_strlen(char *p);
char *my_strcpy(char *destination, char *source);
char *my_strcat(char *strg1, char *strg2);
int my_strcmp(char *strg1, char *strg2);

 

#endif // HMYSTRING_H