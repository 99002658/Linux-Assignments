#ifndef __MYUTILS_H
#define __MYUTILS_H

	int fact(int x);
	bool isPrime(int num);
	int isPalindrome(int num);
	int vsum(int num,...);

#endif
