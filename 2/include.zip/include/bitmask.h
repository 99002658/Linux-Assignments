#ifndef __BITMASK_H
#define __BITMASK_H

	int setBit(int n,int k );
	int resetBit(int n,int k);
	int flip(int num);
	int query(int n,int k );

#endif