#include<cmath>
#include <cstring>
#include "/home/genesis49/Documents/lin/Linux/include/myutils.h"
#include<iostream>
using namespace std;
int fact(int x){

	int f;
	for(int i=1;i<=x;i++){

		f=i*i;
	}
	return f;
}